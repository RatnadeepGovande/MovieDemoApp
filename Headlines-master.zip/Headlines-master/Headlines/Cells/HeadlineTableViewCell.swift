//
//  HeadlineTableViewCell.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/20/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation
import UIKit

class HeadlineTableViewCell : UITableViewCell {
    
    @IBOutlet weak var titleLabel :UILabel!
    @IBOutlet weak var descriptionLabel :UILabel!
    
 
    
}
