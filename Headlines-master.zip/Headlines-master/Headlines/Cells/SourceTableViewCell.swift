//
//  SourceTableViewCell.swift
//  Headlines
//
//  Created by Mohammad Azam on 11/19/17.
//  Copyright © 2017 Mohammad Azam. All rights reserved.
//

import Foundation
import UIKit

class SourceTableViewCell : UITableViewCell {
    
    @IBOutlet weak var nameLabel :UILabel!
    @IBOutlet weak var descriptionLabel :UILabel!
 
    
}
