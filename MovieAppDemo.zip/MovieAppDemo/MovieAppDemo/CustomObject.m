//
//  CustomObject.m
//  MovieAppDemo
//
//  Created by Ratnadeep on 6/14/19.
//  Copyright © 2019 RatnaDeep. All rights reserved.
//

#import "CustomObject.h"

@implementation CustomObject

@end
