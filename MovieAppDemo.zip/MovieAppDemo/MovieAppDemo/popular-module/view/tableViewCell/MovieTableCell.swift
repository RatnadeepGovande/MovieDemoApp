//
//  MovieTableCell.swift
//  MovieAppDemo
//
//  Created by Ratnadeep on 4/8/19.
//  Copyright © 2019 RatnaDeep. All rights reserved.
//

import UIKit

class MovieTableCell: UITableViewCell {
    @IBOutlet weak var title:UILabel!
    @IBOutlet weak var overViewLbl:UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
    
    @IBOutlet weak var movieImage: UIImageView!
    
    private var username: String?
    var movie: Movie? {
        didSet {
            guard let item = movie else {
                return
            }
            title.text = item.title
            overViewLbl.text = item.overview
            releaseDateLbl.text = "Release date: \(item.release_date!)"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    static var nib:UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    static var identifier: String {
        return String(describing: self)
    }
}


//extension MovieTableCell {
//    func updateName() {
//        self.username = "Ratnadeep"
//    }
//}
//
//class SubMovieTableCell : MovieTableCell {
//    func updateName1() {
//
//    }
//}
