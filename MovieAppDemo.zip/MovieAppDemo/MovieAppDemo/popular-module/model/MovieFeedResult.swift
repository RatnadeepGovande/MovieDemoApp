

import Foundation

struct MovieFeedResult: Decodable {
    let results: [Movie]?
    let total_pages: Int?
    let total_results: Int?
    let page: Int?
//
//    enum CodingKeys: String, CodingKey {
//        case page = "page"
//        case totalResult = "total_results"
//        case totalPages = "total_pages"
//        case results = "results"
//    }
//    init(from decoder: Decoder) throws {
//        
//        let values = try decoder.container(keyedBy:CodingKeys.self)
//        page = try values.decode(Int.self, forKey: .page)
//        totalResult = try values.decode(Int.self, forKey: .totalResult)
//        totalPages = try values.decode(Int.self, forKey: .totalPages)
//        results = try values.decode([Movie].self, forKey: .results)
//    }
    
}
