

import Foundation

struct Movie: Decodable {
    let title: String?
    let poster_path: String?
    let overview: String?
    let releaseDate: String?
    let backdrop_path: String?
    let release_date: String?
    
    
//    enum CodingKeys: String,CodingKey {
//        case title
//        case poster_path
//        case overview
//        case releaseDate
//        case backdrop_path
//        case release_date
//    }
//    
//    init(from decoder: Decoder) throws {
//        let values = try decoder.container(keyedBy: CodingKeys.self)
//         title = try values.decode(String.self, forKey: .title)
//        poster_path = try values.decode(String.self, forKey: .poster_path)
//        overview = try values.decode(String.self, forKey: .overview)
//        releaseDate = try values.decode(String.self, forKey: .releaseDate)
//        backdrop_path = try values.decode(String.self, forKey: .backdrop_path)
//        release_date = try values.decode(String.self, forKey: .release_date)
//    }
}
