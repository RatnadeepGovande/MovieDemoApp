//
//  MovieViewModel.swift
//  MovieAppDemo
//
//  Created by Ratnadeep on 4/8/19.
//  Copyright © 2019 RatnaDeep. All rights reserved.
//

import Foundation
import UIKit

class MovieViewModel: NSObject {
    private let client = MovieClient()
    private var movies:[Movie]?
    
    var reloadTableRow:((_ row: Int) -> Void)?
    var didSelectedItem:((_ row: Int, _ item: Movie?) -> Void)?
    
    override init() {
        super.init()
    }
    
    
    func getMovieData() {
        client.getFeed(from: .nowPlaying) { [unowned self] result in
            switch result {
            case .success(let movieFeedResult):
                guard let movieResults = movieFeedResult?.results else { return }
                print(movieResults)
                self.movies = movieResults
                self.reloadTableRow?(0)
            case .failure(let error):
                print("the error \(error)")
            }
        }
    }
    
}

extension MovieViewModel:UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = self.movies?.count {
            print("\(count)")
            return count
        }else {
            return 0
        }
    }
    
    func  tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: MovieTableCell = tableView.dequeueReusableCell(withIdentifier: MovieTableCell.identifier, for: indexPath) as! MovieTableCell
        cell.movie = movies?[indexPath.row]
        return cell
    }
}

extension MovieViewModel: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.didSelectedItem?(indexPath.row, movies?[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        print("Index Path row :\(indexPath.row)")
    }
}


