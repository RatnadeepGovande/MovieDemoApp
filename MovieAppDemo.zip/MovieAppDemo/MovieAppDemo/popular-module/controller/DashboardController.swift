//
//  DashboardController.swift
//  MovieAppDemo
//
//  Created by Ratnadeep on 4/5/19.
//  Copyright © 2019 RatnaDeep. All rights reserved.
//

import UIKit


var defaultDic: [String:String] = ["Name":"Ratnadeep","email":"ratnadeep@gmail.com"]

class DashboardController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private let client = MovieClient()
    fileprivate let movieViewModel = MovieViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
        movieViewModel.reloadTableRow = {[weak self] row in
            self?.tableView.reloadData()
        }
        tableView.dataSource = movieViewModel
        tableView.delegate = movieViewModel
        movieViewModel.getMovieData()
        tableView?.register(MovieTableCell.nib, forCellReuseIdentifier: MovieTableCell.identifier)
        
        movieViewModel.didSelectedItem = {[weak self] (row, item) in
            print("Selected Row \(item)")
        }
    }
    
}
